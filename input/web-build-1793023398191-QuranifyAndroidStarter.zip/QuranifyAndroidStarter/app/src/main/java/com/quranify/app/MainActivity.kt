package com.quranify.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val DeepGreen = Color(0xFF061D17)
private val PanelGreen = Color(0xFF0D3025)
private val Mint = Color(0xFF48E0A4)
private val Cream = Color(0xFFF2F5F0)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { QuranifyApp() }
    }
}

data class Surah(val number: Int, val name: String, val verses: Int)
data class Reciter(val name: String, val description: String)

@Composable
fun QuranifyApp() {
    var page by remember { mutableStateOf("Home") }
    var selectedSurah by remember { mutableStateOf("Al-Fatihah") }
    var playing by remember { mutableStateOf(false) }
    val surahs = remember {
        listOf(
            Surah(1, "Al-Fatihah", 7), Surah(2, "Al-Baqarah", 286),
            Surah(3, "Ali 'Imran", 200), Surah(4, "An-Nisa", 176),
            Surah(5, "Al-Ma'idah", 120), Surah(6, "Al-An'am", 165),
            Surah(7, "Al-A'raf", 206), Surah(8, "Al-Anfal", 75)
        )
    }
    val reciters = remember {
        listOf(
            Reciter("Sheikh Muhammad Siddiq al-Minshawi", "Qari • audio source to be configured"),
            Reciter("Abdul Basit Abdus Samad", "Qari • audio source to be configured"),
            Reciter("Mishary Rashid Alafasy", "Qari • audio source to be configured")
        )
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Mint, background = DeepGreen, surface = PanelGreen,
        onPrimary = DeepGreen, onBackground = Cream, onSurface = Cream
    )) {
        Scaffold(
            containerColor = DeepGreen,
            bottomBar = {
                NavigationBar(containerColor = PanelGreen, contentColor = Mint) {
                    listOf("Home", "Surahs", "Qaris", "Admin").forEach { item ->
                        NavigationBarItem(
                            selected = page == item,
                            onClick = { page = item },
                            icon = { Text(when(item) { "Home" -> "⌂"; "Surahs" -> "♫"; "Qaris" -> "◉"; else -> "⚙" }, fontSize = 20.sp) },
                            label = { Text(item) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Mint, selectedTextColor = Mint,
                                indicatorColor = DeepGreen, unselectedTextColor = Cream
                            )
                        )
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp)) {
                Spacer(Modifier.height(18.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("◈", color = Mint, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.width(8.dp))
                    Column {
                        Text("Quranify", color = Cream, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                        Text("Listen • Learn • Connect", color = Mint, fontSize = 12.sp)
                    }
                }
                Spacer(Modifier.height(20.dp))
                when (page) {
                    "Home" -> {
                        Text("Assalamu Alaikum", color = Cream, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        Text("Your Quran, anytime. Anywhere.", color = Cream.copy(alpha=.7f))
                        Spacer(Modifier.height(18.dp))
                        Card(colors = CardDefaults.cardColors(containerColor = PanelGreen), shape = RoundedCornerShape(22.dp)) {
                            Column(Modifier.fillMaxWidth().padding(20.dp)) {
                                Text("THE HOLY QURAN", color = Mint, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(8.dp))
                                Text("Find peace in every verse", color = Cream, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(12.dp))
                                Button(onClick = { page = "Surahs" }) { Text("Explore Surahs") }
                            }
                        }
                        Spacer(Modifier.height(22.dp))
                        SectionTitle("Continue listening")
                        PlayerCard(selectedSurah, playing, { playing = !playing }, { page = "Surahs" })
                        Spacer(Modifier.height(22.dp))
                        SectionTitle("Popular Qaris")
                        reciters.take(3).forEach { Text("🎙  ${it.name}", color = Cream, modifier = Modifier.padding(vertical = 8.dp)) }
                    }
                    "Surahs" -> {
                        SectionTitle("Surah Library")
                        Text("Choose a surah to open the player", color = Cream.copy(alpha=.65f))
                        LazyColumn {
                            items(surahs) { surah ->
                                Row(Modifier.fillMaxWidth().clickable {
                                    selectedSurah = surah.name; page = "Home"; playing = true
                                }.padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Box(Modifier.size(42.dp).background(PanelGreen, RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                                        Text(surah.number.toString(), color = Mint, fontWeight = FontWeight.Bold)
                                    }
                                    Spacer(Modifier.width(12.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(surah.name, color = Cream, fontWeight = FontWeight.SemiBold)
                                        Text("${surah.verses} verses", color = Cream.copy(alpha=.6f), fontSize = 12.sp)
                                    }
                                    Text("▶", color = Mint)
                                }
                                HorizontalDivider(color = Cream.copy(alpha=.08f))
                            }
                        }
                    }
                    "Qaris" -> {
                        SectionTitle("Qaris")
                        Text("Reciter catalogue • connect Firebase to publish updates", color = Cream.copy(alpha=.65f))
                        Spacer(Modifier.height(12.dp))
                        reciters.forEach {
                            Card(Modifier.fillMaxWidth().padding(vertical = 5.dp), colors = CardDefaults.cardColors(containerColor = PanelGreen)) {
                                Column(Modifier.padding(16.dp)) {
                                    Text(it.name, color = Cream, fontWeight = FontWeight.Bold)
                                    Text(it.description, color = Mint, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                    else -> AdminSetupScreen()
                }
            }
        }
    }
}

@Composable
fun SectionTitle(title: String) {
    Text(title, color = Cream, fontSize = 19.sp, fontWeight = FontWeight.Bold)
}

@Composable
fun PlayerCard(title: String, playing: Boolean, onPlay: () -> Unit, onOpen: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = PanelGreen), shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(54.dp).background(DeepGreen, RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                Text("۞", color = Mint, fontSize = 30.sp)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = Cream, fontWeight = FontWeight.Bold)
                Text("Quran recitation", color = Cream.copy(alpha=.65f), fontSize = 12.sp)
            }
            Button(onClick = onPlay) { Text(if (playing) "Ⅱ" else "▶") }
        }
    }
}

@Composable
fun AdminSetupScreen() {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("Connect Firebase and configure admin access to enable management.") }
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Secure Admin", color = Cream, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("Admin sign-in", color = Mint)
        OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("Admin email") }, singleLine = true)
        OutlinedTextField(value = password, onValueChange = { password = it }, label = { Text("Password") }, singleLine = true)
        Button(onClick = {
            message = "Setup required: add your Firebase project, create an authorized admin account, and apply the security rules in README."
        }, modifier = Modifier.fillMaxWidth()) { Text("Sign in") }
        Text(message, color = Cream.copy(alpha=.75f), fontSize = 13.sp)
        Card(colors = CardDefaults.cardColors(containerColor = PanelGreen)) {
            Column(Modifier.padding(16.dp)) {
                Text("Admin tools planned", color = Mint, fontWeight = FontWeight.Bold)
                Text("• Add / edit / delete Qaris\n• Add Surahs and audio URLs\n• Upload audio files\n• Publish catalogue updates online", color = Cream)
            }
        }
    }
}
