# Quranify Android Starter

A Kotlin + Jetpack Compose starter for a dark-green Quran audio streaming app.

## Important status
This is a **starter UI project**, not a finished production app yet. The player UI currently demonstrates navigation only; it does not stream audio until a playback engine and verified audio URLs are configured. The Admin screen is a setup placeholder and does not authenticate or write data yet. Do not publish it as a secure admin app until Firebase authentication, role checks, database/storage rules, and audio playback are implemented and tested.

## Open in Android Studio
1. Extract the ZIP.
2. Open the `QuranifyAndroidStarter` folder in Android Studio.
3. Let Gradle sync.
4. Create a Firebase project at https://console.firebase.google.com/
5. Add an Android app with package name `com.quranify.app`.
6. Download `google-services.json` and place it in the `app/` folder.
7. Enable **Email/Password** in Firebase Authentication.
8. Enable Cloud Firestore and Firebase Storage.
9. Sync Gradle and run on an Android device.

## Secure admin architecture (required before launch)
- Never put an admin password or service-account key in the app.
- Create admin users in Firebase Authentication.
- Use a trusted backend (for example, Firebase Cloud Functions) to assign/check admin roles, or use custom claims set by a trusted environment.
- Firestore rules must deny writes unless `request.auth != null` and the user has the admin claim.
- Storage rules must restrict audio uploads to authenticated admins and validate file size/type.
- Public users may read only published Qari/Surah catalogue entries.
- Keep private drafts/admin metadata inaccessible to ordinary users.

## Suggested Firestore structure
- `reciters/{reciterId}`: `name`, `photoUrl`, `bio`, `published`, `createdAt`
- `surahs/{surahId}`: `number`, `nameArabic`, `nameTransliteration`, `ayahCount`, `published`
- `audioTracks/{trackId}`: `reciterId`, `surahNumber`, `audioUrl`, `durationSeconds`, `published`
- Store audio files in Firebase Storage or a licensed audio CDN; save only their download URL/metadata in Firestore.

## Audio rights and accuracy
Use audio sources you have permission to stream and download. Verify reciter attribution, complete surah files, and correct metadata before publishing.

## Next implementation steps
1. Firebase Auth + trusted admin-role verification.
2. Firestore repository for live Qari/Surah catalogue.
3. Firebase Storage upload workflow for admin.
4. Real audio playback using Media3/ExoPlayer with background playback controls.
5. Download/offline support, favorites, playlists, search, and tests.
