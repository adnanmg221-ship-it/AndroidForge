package com.quranify.app

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer

private val Background = Color(0xFF061A14)
private val SurfaceGreen = Color(0xFF0D2A20)
private val CardGreen = Color(0xFF12372A)
private val Mint = Color(0xFF43D6A0)
private val Gold = Color(0xFFD8BB72)
private val Muted = Color(0xFFA8BDB2)
private val White = Color(0xFFF3F8F4)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(6, 26, 20)
        window.navigationBarColor = android.graphics.Color.rgb(6, 26, 20)
        setContent { QuranifyApp(this) }
    }
}

private data class Surah(val number: Int, val arabic: String, val english: String, val verses: Int)
private data class Reciter(val name: String, val arabic: String, val folder: String)

private val surahs = listOf(
    Surah(1,"الفاتحة","Al-Fatihah",7), Surah(2,"البقرة","Al-Baqarah",286),
    Surah(3,"آل عمران","Ali 'Imran",200), Surah(4,"النساء","An-Nisa",176),
    Surah(5,"المائدة","Al-Ma'idah",120), Surah(6,"الأنعام","Al-An'am",165),
    Surah(7,"الأعراف","Al-A'raf",206), Surah(8,"الأنفال","Al-Anfal",75),
    Surah(9,"التوبة","At-Tawbah",129), Surah(10,"يونس","Yunus",109),
    Surah(11,"هود","Hud",123), Surah(12,"يوسف","Yusuf",111),
    Surah(13,"الرعد","Ar-Ra'd",43), Surah(14,"إبراهيم","Ibrahim",52),
    Surah(15,"الحجر","Al-Hijr",99), Surah(16,"النحل","An-Nahl",128),
    Surah(17,"الإسراء","Al-Isra",111), Surah(18,"الكهف","Al-Kahf",110),
    Surah(19,"مريم","Maryam",98), Surah(20,"طه","Ta-Ha",135),
    Surah(21,"الأنبياء","Al-Anbiya",112), Surah(22,"الحج","Al-Hajj",78),
    Surah(23,"المؤمنون","Al-Mu'minun",118), Surah(24,"النور","An-Nur",64),
    Surah(25,"الفرقان","Al-Furqan",77), Surah(26,"الشعراء","Ash-Shu'ara",227),
    Surah(27,"النمل","An-Naml",93), Surah(28,"القصص","Al-Qasas",88),
    Surah(29,"العنكبوت","Al-Ankabut",69), Surah(30,"الروم","Ar-Rum",60),
    Surah(31,"لقمان","Luqman",34), Surah(32,"السجدة","As-Sajdah",30),
    Surah(33,"الأحزاب","Al-Ahzab",73), Surah(34,"سبأ","Saba",54),
    Surah(35,"فاطر","Fatir",45), Surah(36,"يس","Ya-Sin",83),
    Surah(37,"الصافات","As-Saffat",182), Surah(38,"ص","Sad",88),
    Surah(39,"الزمر","Az-Zumar",75), Surah(40,"غافر","Ghafir",85),
    Surah(41,"فصلت","Fussilat",54), Surah(42,"الشورى","Ash-Shura",53),
    Surah(43,"الزخرف","Az-Zukhruf",89), Surah(44,"الدخان","Ad-Dukhan",59),
    Surah(45,"الجاثية","Al-Jathiyah",37), Surah(46,"الأحقاف","Al-Ahqaf",35),
    Surah(47,"محمد","Muhammad",38), Surah(48,"الفتح","Al-Fath",29),
    Surah(49,"الحجرات","Al-Hujurat",18), Surah(50,"ق","Qaf",45),
    Surah(51,"الذاريات","Adh-Dhariyat",60), Surah(52,"الطور","At-Tur",49),
    Surah(53,"النجم","An-Najm",62), Surah(54,"القمر","Al-Qamar",55),
    Surah(55,"الرحمن","Ar-Rahman",78), Surah(56,"الواقعة","Al-Waqi'ah",96),
    Surah(57,"الحديد","Al-Hadid",29), Surah(58,"المجادلة","Al-Mujadila",22),
    Surah(59,"الحشر","Al-Hashr",24), Surah(60,"الممتحنة","Al-Mumtahanah",13),
    Surah(61,"الصف","As-Saff",14), Surah(62,"الجمعة","Al-Jumu'ah",11),
    Surah(63,"المنافقون","Al-Munafiqun",11), Surah(64,"التغابن","At-Taghabun",18),
    Surah(65,"الطلاق","At-Talaq",12), Surah(66,"التحريم","At-Tahrim",12),
    Surah(67,"الملك","Al-Mulk",30), Surah(68,"القلم","Al-Qalam",52),
    Surah(69,"الحاقة","Al-Haqqah",52), Surah(70,"المعارج","Al-Ma'arij",44),
    Surah(71,"نوح","Nuh",28), Surah(72,"الجن","Al-Jinn",28),
    Surah(73,"المزمل","Al-Muzzammil",20), Surah(74,"المدثر","Al-Muddaththir",56),
    Surah(75,"القيامة","Al-Qiyamah",40), Surah(76,"الإنسان","Al-Insan",31),
    Surah(77,"المرسلات","Al-Mursalat",50), Surah(78,"النبأ","An-Naba",40),
    Surah(79,"النازعات","An-Nazi'at",46), Surah(80,"عبس","Abasa",42),
    Surah(81,"التكوير","At-Takwir",29), Surah(82,"الانفطار","Al-Infitar",19),
    Surah(83,"المطففين","Al-Mutaffifin",36), Surah(84,"الانشقاق","Al-Inshiqaq",25),
    Surah(85,"البروج","Al-Buruj",22), Surah(86,"الطارق","At-Tariq",17),
    Surah(87,"الأعلى","Al-A'la",19), Surah(88,"الغاشية","Al-Ghashiyah",26),
    Surah(89,"الفجر","Al-Fajr",30), Surah(90,"البلد","Al-Balad",20),
    Surah(91,"الشمس","Ash-Shams",15), Surah(92,"الليل","Al-Layl",21),
    Surah(93,"الضحى","Ad-Duha",11), Surah(94,"الشرح","Ash-Sharh",8),
    Surah(95,"التين","At-Tin",8), Surah(96,"العلق","Al-Alaq",19),
    Surah(97,"القدر","Al-Qadr",5), Surah(98,"البينة","Al-Bayyinah",8),
    Surah(99,"الزلزلة","Az-Zalzalah",8), Surah(100,"العاديات","Al-Adiyat",11),
    Surah(101,"القارعة","Al-Qari'ah",11), Surah(102,"التكاثر","At-Takathur",8),
    Surah(103,"العصر","Al-Asr",3), Surah(104,"الهمزة","Al-Humazah",9),
    Surah(105,"الفيل","Al-Fil",5), Surah(106,"قريش","Quraysh",4),
    Surah(107,"الماعون","Al-Ma'un",7), Surah(108,"الكوثر","Al-Kawthar",3),
    Surah(109,"الكافرون","Al-Kafirun",6), Surah(110,"النصر","An-Nasr",3),
    Surah(111,"المسد","Al-Masad",5), Surah(112,"الإخلاص","Al-Ikhlas",4),
    Surah(113,"الفلق","Al-Falaq",5), Surah(114,"الناس","An-Nas",6)
)

private val reciters = listOf(
    Reciter("Mishary Rashid Alafasy","مشاري العفاسي","Alafasy_128kbps"),
    Reciter("Abdul Basit Abdus Samad","عبد الباسط عبد الصمد","Abdul_Basit_Murattal_192kbps"),
    Reciter("Mahmoud Khalil Al-Husary","محمود خليل الحصري","Husary_128kbps"),
    Reciter("Mohamed Siddiq Al-Minshawi","محمد صديق المنشاوي","Minshawy_Murattal_128kbps"),
    Reciter("Saad Al-Ghamdi","سعد الغامدي","Ghamadi_40kbps"),
    Reciter("Maher Al-Muaiqly","ماهر المعيقلي","Maher Al Muaiqly 128kbps")
)

@Composable
private fun QuranifyApp(context: Context) {
    var selectedTab by remember { mutableStateOf("Home") }
    var query by remember { mutableStateOf("") }
    var currentSurah by remember { mutableStateOf(surahs.first()) }
    var currentReciter by remember { mutableStateOf(reciters.first()) }
    var playing by remember { mutableStateOf(false) }
    var favorites by remember { mutableStateOf(setOf<Int>()) }
    var downloaded by remember { mutableStateOf(setOf<Int>()) }
    var showPlayer by remember { mutableStateOf(false) }
    var showAdmin by remember { mutableStateOf(false) }
    var adminLoggedIn by remember { mutableStateOf(false) }
    var adminUser by remember { mutableStateOf("") }
    var adminPass by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    val player = remember { ExoPlayer.Builder(context).build() }

    DisposableEffect(Unit) { onDispose { player.release() } }

    fun playSurah(surah: Surah) {
        currentSurah = surah
        val audioNumber = "%03d".format(surah.number)
        val url = "https://everyayah.com/data/${currentReciter.folder}/${audioNumber}001.mp3"
        try {
            player.setMediaItem(MediaItem.fromUri(Uri.parse(url)))
            player.prepare()
            player.playWhenReady = true
            playing = true
            showPlayer = true
            message = "Streaming ${surah.english}"
        } catch (_: Exception) {
            playing = false
            message = "Audio could not be started. Please check your internet connection."
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Mint, secondary = Gold, background = Background, surface = SurfaceGreen,
        onBackground = White, onSurface = White
    )) {
        Scaffold(
            containerColor = Background,
            bottomBar = {
                NavigationBar(containerColor = SurfaceGreen, contentColor = Muted) {
                    val tabs = listOf(
                        Triple("Home", Icons.Default.Home, "Home"),
                        Triple("Surahs", Icons.Default.MenuBook, "Surahs"),
                        Triple("Library", Icons.Default.LibraryMusic, "Library"),
                        Triple("Settings", Icons.Default.Settings, "Settings")
                    )
                    tabs.forEach { (label, icon, _) ->
                        NavigationBarItem(
                            selected = selectedTab == label,
                            onClick = { selectedTab = label; query = "" },
                            icon = { Icon(icon, contentDescription = label) },
                            label = { Text(label, fontSize = 11.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Mint, selectedTextColor = Mint,
                                indicatorColor = Mint.copy(alpha = .12f),
                                unselectedIconColor = Muted, unselectedTextColor = Muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        Modifier.size(44.dp).clip(RoundedCornerShape(14.dp))
                            .background(Brush.linearGradient(listOf(Mint.copy(.28f), Gold.copy(.12f)))),
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Default.MenuBook, null, tint = Mint, modifier = Modifier.size(27.dp)) }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Quranify", color = White, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
                        Text("LISTEN  •  LEARN  •  CONNECT", color = Muted, fontSize = 9.sp, letterSpacing = 1.3.sp)
                    }
                    IconButton(onClick = { selectedTab = "Settings" }) {
                        Icon(Icons.Default.NotificationsNone, "Notifications", tint = Gold)
                    }
                }

                when (selectedTab) {
                    "Home" -> HomeScreen(
                        query, { query = it }, currentSurah, playing,
                        onPlay = { playSurah(currentSurah) },
                        onSurah = { currentSurah = it; playSurah(it) },
                        onTab = { selectedTab = it },
                        onFavorite = { s -> favorites = if (s.number in favorites) favorites - s.number else favorites + s.number },
                        favorites = favorites,
                        currentReciter = currentReciter,
                        onReciter = { currentReciter = it },
                        onPlayer = { showPlayer = true }
                    )
                    "Surahs" -> SurahScreen(
                        query, { query = it }, onPlay = { playSurah(it) },
                        favorites = favorites,
                        onFavorite = { s -> favorites = if (s.number in favorites) favorites - s.number else favorites + s.number }
                    )
                    "Reciters" -> RecitersScreen(currentReciter, onSelect = { currentReciter = it; selectedTab = "Home"; message = "Selected ${it.name}" })
                    "Library" -> LibraryScreen(
                        favorites.mapNotNull { n -> surahs.find { it.number == n } },
                        downloaded.mapNotNull { n -> surahs.find { it.number == n } },
                        onPlay = { playSurah(it) },
                        onDownloads = { selectedTab = "Downloads" }
                    )
                    "Downloads" -> LibraryScreen(
                        emptyList(), downloaded.mapNotNull { n -> surahs.find { it.number == n } },
                        onPlay = { playSurah(it) }, onDownloads = { selectedTab = "Downloads" }
                    )
                    "Settings" -> SettingsScreen(
                        currentReciter = currentReciter,
                        onReciter = { currentReciter = it },
                        onAdmin = { showAdmin = true },
                        onDownloads = { selectedTab = "Downloads" }
                    )
                    else -> SurahScreen(query, { query = it }, onPlay = { playSurah(it) }, favorites = favorites,
                        onFavorite = { s -> favorites = if (s.number in favorites) favorites - s.number else favorites + s.number })
                }

                if (message.isNotBlank()) {
                    Text(message, color = Mint, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 20.dp, vertical = 3.dp))
                }
            }
        }

        if (showPlayer) {
            PlayerDialog(
                surah = currentSurah, reciter = currentReciter, playing = playing,
                onToggle = {
                    if (player.isPlaying) { player.pause(); playing = false }
                    else if (player.mediaItemCount > 0) { player.play(); playing = true }
                    else playSurah(currentSurah)
                },
                onClose = { showPlayer = false },
                onNext = { val next = surahs.getOrNull(currentSurah.number) ?: surahs.first(); playSurah(next) },
                onPrevious = { val previous = surahs.getOrNull(currentSurah.number - 2) ?: surahs.last(); playSurah(previous) },
                onDownload = {
                    try {
                        val n = "%03d".format(currentSurah.number)
                        val url = "https://everyayah.com/data/${currentReciter.folder}/$n" + "001.mp3"
                        val request = DownloadManager.Request(Uri.parse(url))
                            .setTitle("${currentSurah.english} - Quranify")
                            .setDescription("Downloading recitation audio")
                            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                            .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "Quranify_${n}_001.mp3")
                        (context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
                        downloaded = downloaded + currentSurah.number
                        message = "Download started. Full Surah audio may require multiple verse files."
                    } catch (_: Exception) { message = "Download could not be started." }
                }
            )
        }

        if (showAdmin) {
            AlertDialog(
                onDismissRequest = { showAdmin = false },
                containerColor = SurfaceGreen,
                title = { Text(if (adminLoggedIn) "Quranify Admin" else "Admin Login", color = White) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        if (!adminLoggedIn) {
                            OutlinedTextField(adminUser, { adminUser = it }, label = { Text("Username") }, singleLine = true)
                            OutlinedTextField(adminPass, { adminPass = it }, label = { Text("Password") }, singleLine = true)
                            Text("Demo UI only. Configure Firebase Authentication before production use.", color = Gold, fontSize = 12.sp)
                        } else {
                            Text("Dashboard preview", color = Mint, fontWeight = FontWeight.Bold)
                            Text("114 Surahs • ${reciters.size} reciters • ${favorites.size} favorites")
                            Text("For secure uploads and management, connect Firebase and configure server-side access rules.", color = Muted, fontSize = 12.sp)
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        if (adminLoggedIn) showAdmin = false
                        else { adminLoggedIn = true; message = "Demo dashboard opened — no authentication is configured." }
                    }) { Text(if (adminLoggedIn) "Close" else "Preview dashboard", color = Mint) }
                },
                dismissButton = { TextButton(onClick = { showAdmin = false }) { Text("Cancel", color = Muted) } }
            )
        }
    }
}

@Composable
private fun HomeScreen(
    query: String, onQuery: (String) -> Unit, currentSurah: Surah, playing: Boolean,
    onPlay: () -> Unit, onSurah: (Surah) -> Unit, onTab: (String) -> Unit,
    onFavorite: (Surah) -> Unit, favorites: Set<Int>, currentReciter: Reciter,
    onReciter: (Reciter) -> Unit, onPlayer: () -> Unit
) {
    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 18.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(bottom = 20.dp)
    ) {
        item {
            OutlinedTextField(
                value = query, onValueChange = onQuery, modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Search Surah, Qari...", color = Muted) },
                leadingIcon = { Icon(Icons.Default.Search, null, tint = Mint) },
                trailingIcon = { if (query.isNotBlank()) IconButton(onClick = { onQuery("") }) { Icon(Icons.Default.Close, null) } },
                singleLine = true, shape = RoundedCornerShape(18.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Mint, unfocusedBorderColor = CardGreen,
                    focusedTextColor = White, unfocusedTextColor = White,
                    cursorColor = Mint, focusedContainerColor = SurfaceGreen, unfocusedContainerColor = SurfaceGreen
                )
            )
        }
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = CardGreen)
            ) {
                Box(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(Color(0xFF164B37), Color(0xFF0D2A20)))).padding(20.dp)) {
                    Column {
                        Text("YOUR DAILY RECITATION", color = Mint, fontSize = 10.sp, letterSpacing = 1.4.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(10.dp))
                        Text("The Holy Quran", color = White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                        Text("Guidance for a better life", color = Muted, fontSize = 13.sp)
                        Spacer(Modifier.height(16.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Button(onClick = onPlay, colors = ButtonDefaults.buttonColors(containerColor = Mint, contentColor = Background)) {
                                Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null)
                                Spacer(Modifier.width(5.dp)); Text(if (playing) "Playing" else "Listen Now")
                            }
                            Spacer(Modifier.width(10.dp))
                            Text("بِسْمِ اللَّهِ", color = Gold, fontSize = 25.sp)
                        }
                    }
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                QuickAction("All Surahs", Icons.Default.MenuBook, Modifier.weight(1f)) { onTab("Surahs") }
                QuickAction("Qari", Icons.Default.RecordVoiceOver, Modifier.weight(1f)) { onTab("Reciters") }
                QuickAction("Favorites", Icons.Default.FavoriteBorder, Modifier.weight(1f)) { onTab("Library") }
                QuickAction("Downloads", Icons.Default.Download, Modifier.weight(1f)) { onTab("Downloads") }
            }
        }
        item { SectionHeading("Popular Qaris", "See all") { onTab("Reciters") } }
        items(reciters.take(4)) { reciter ->
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(SurfaceGreen)
                    .clickable { onReciter(reciter) }.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Avatar(reciter.name.take(1))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(reciter.name, color = White, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(reciter.arabic, color = Muted, fontSize = 12.sp)
                }
                Icon(if (currentReciter == reciter) Icons.Default.CheckCircle else Icons.Default.PlayCircle,
                    null, tint = Mint, modifier = Modifier.clickable { onReciter(reciter) })
            }
        }
        item { SectionHeading("Recently played", "Open player") { onPlayer() } }
        item {
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(SurfaceGreen).clickable { onSurah(currentSurah) }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                SurahNumber(currentSurah.number)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(currentSurah.english, color = White, fontWeight = FontWeight.Bold)
                    Text("${currentReciter.name} • ${currentSurah.verses} verses", color = Muted, fontSize = 12.sp)
                }
                Icon(Icons.Default.PlayCircle, null, tint = Mint)
            }
        }
        if (query.isNotBlank()) {
            item { SectionHeading("Search results", "") {} }
            items(surahs.filter { it.english.contains(query, true) || it.arabic.contains(query) || it.number.toString() == query }) { surah ->
                SurahRow(surah, surah.number in favorites, { onSurah(surah) }, { onFavorite(surah) })
            }
        }
    }
}

@Composable
private fun QuickAction(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier.clip(RoundedCornerShape(15.dp)).background(SurfaceGreen).clickable(onClick = onClick).padding(vertical = 13.dp, horizontal = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, null, tint = Mint, modifier = Modifier.size(22.dp))
        Spacer(Modifier.height(6.dp))
        Text(label, color = Muted, fontSize = 10.sp, maxLines = 1)
    }
}

@Composable
private fun SectionHeading(title: String, action: String, onAction: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = White, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        if (action.isNotBlank()) TextButton(onClick = onAction, contentPadding = PaddingValues(0.dp)) { Text(action, color = Mint, fontSize = 12.sp) }
    }
}

@Composable
private fun Avatar(letter: String) {
    Box(Modifier.size(46.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Mint.copy(.32f), Gold.copy(.22f)))),
        contentAlignment = Alignment.Center) {
        Text(letter.take(1).uppercase(), color = Mint, fontWeight = FontWeight.Bold, fontSize = 19.sp)
    }
}

@Composable
private fun SurahNumber(number: Int) {
    Box(Modifier.size(42.dp).clip(RoundedCornerShape(13.dp)).background(CardGreen), contentAlignment = Alignment.Center) {
        Text(number.toString(), color = Mint, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun SurahScreen(query: String, onQuery: (String) -> Unit, onPlay: (Surah) -> Unit,
                        favorites: Set<Int>, onFavorite: (Surah) -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
        Text("All Surahs", color = White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text("114 chapters of the Holy Quran", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(query, onQuery, Modifier.fillMaxWidth(),
            placeholder = { Text("Search by name or number") },
            leadingIcon = { Icon(Icons.Default.Search, null, tint = Mint) },
            singleLine = true, shape = RoundedCornerShape(16.dp))
        Spacer(Modifier.height(10.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 18.dp)) {
            items(surahs.filter { it.english.contains(query, true) || it.arabic.contains(query) || it.number.toString() == query }) { surah ->
                SurahRow(surah, surah.number in favorites, { onPlay(surah) }, { onFavorite(surah) })
            }
        }
    }
}

@Composable
private fun SurahRow(surah: Surah, favorite: Boolean, onPlay: () -> Unit, onFavorite: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(17.dp)).background(SurfaceGreen).padding(horizontal = 12.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        SurahNumber(surah.number)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(surah.english, color = White, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("${surah.verses} verses", color = Muted, fontSize = 11.sp)
        }
        Text(surah.arabic, color = Gold, fontSize = 18.sp)
        IconButton(onClick = onFavorite) { Icon(if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = if (favorite) Gold else Muted) }
        IconButton(onClick = onPlay) { Icon(Icons.Default.PlayCircle, null, tint = Mint) }
    }
}


@Composable
private fun RecitersScreen(current: Reciter, onSelect: (Reciter) -> Unit) {
    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 18.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(bottom = 20.dp)
    ) {
        item {
            Text("Qaris", color = White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
            Text("Choose your preferred reciter", color = Muted, fontSize = 13.sp)
            Spacer(Modifier.height(8.dp))
        }
        items(reciters) { reciter ->
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(17.dp))
                    .background(if (reciter == current) CardGreen else SurfaceGreen)
                    .clickable { onSelect(reciter) }.padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Avatar(reciter.name.first().toString())
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(reciter.name, color = White, fontWeight = FontWeight.SemiBold)
                    Text(reciter.arabic, color = Gold, fontSize = 13.sp)
                    Text("114 Surahs • Audio streaming", color = Muted, fontSize = 11.sp)
                }
                Icon(if (reciter == current) Icons.Default.CheckCircle else Icons.Default.ChevronRight,
                    null, tint = Mint)
            }
        }
    }
}

@Composable
private fun LibraryScreen(favorites: List<Surah>, downloads: List<Surah>, onPlay: (Surah) -> Unit, onDownloads: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 20.dp)) {
        item {
            Text("Your Library", color = White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
            Text("Favorites, downloads and collections", color = Muted, fontSize = 13.sp)
            Spacer(Modifier.height(8.dp))
        }
        item { SectionHeading("Favorites", "") {} }
        if (favorites.isEmpty()) item { EmptyState("No favorites yet", "Tap the heart beside a Surah to save it here.") }
        items(favorites) { SurahRow(it, true, { onPlay(it) }, {}) }
        item {
            Spacer(Modifier.height(8.dp))
            SectionHeading("Offline downloads", "Manage") { onDownloads() }
        }
        if (downloads.isEmpty()) item { EmptyState("No downloads yet", "Open a Surah player and tap Download to save audio.") }
        items(downloads) { SurahRow(it, false, { onPlay(it) }, {}) }
        item {
            Spacer(Modifier.height(8.dp))
            SectionHeading("Playlists", "") {}
            listOf("Morning Quran", "Evening Quran", "Relaxing Tilawat").forEachIndexed { i, name ->
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(SurfaceGreen).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.QueueMusic, null, tint = if (i == 1) Gold else Mint, modifier = Modifier.size(32.dp))
                    Spacer(Modifier.width(12.dp))
                    Column { Text(name, color = White, fontWeight = FontWeight.SemiBold); Text("Playlist preview • add Surahs anytime", color = Muted, fontSize = 11.sp) }
                }
                Spacer(Modifier.height(8.dp))
            }
        }
    }
}

@Composable
private fun EmptyState(title: String, detail: String) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(SurfaceGreen).padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Default.LibraryMusic, null, tint = Mint, modifier = Modifier.size(28.dp))
        Spacer(Modifier.height(6.dp))
        Text(title, color = White, fontWeight = FontWeight.SemiBold)
        Text(detail, color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun SettingsScreen(currentReciter: Reciter, onReciter: (Reciter) -> Unit, onAdmin: () -> Unit, onDownloads: () -> Unit) {
    var language by remember { mutableStateOf("English") }
    var quality by remember { mutableStateOf("High") }
    var notifications by remember { mutableStateOf(true) }
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            Text("Settings", color = White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
            Text("Make Quranify your own", color = Muted, fontSize = 13.sp)
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(SurfaceGreen).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Avatar("Q")
                Spacer(Modifier.width(12.dp))
                Column { Text("Quranify User", color = White, fontWeight = FontWeight.Bold); Text("Local profile • no account connected", color = Muted, fontSize = 12.sp) }
            }
        }
        item { Text("PLAYBACK", color = Gold, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp) }
        item {
            SettingRow(Icons.Default.RecordVoiceOver, "Default reciter", currentReciter.name)
            Spacer(Modifier.height(6.dp))
            reciters.forEach { r ->
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(13.dp)).background(if (r == currentReciter) CardGreen else SurfaceGreen)
                    .clickable { onReciter(r) }.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(r.name, color = White, modifier = Modifier.weight(1f), fontSize = 13.sp)
                    if (r == currentReciter) Icon(Icons.Default.CheckCircle, null, tint = Mint)
                }
            }
        }
        item {
            SettingRow(Icons.Default.HighQuality, "Audio quality", quality)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Low", "Medium", "High").forEach { option ->
                    FilterChip(selected = quality == option, onClick = { quality = option }, label = { Text(option) })
                }
            }
        }
        item {
            SettingRow(Icons.Default.Language, "Language", language)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("English", "اردو", "العربية").forEach { option ->
                    FilterChip(selected = language == option, onClick = { language = option }, label = { Text(option) })
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(SurfaceGreen).padding(horizontal = 14.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Notifications, null, tint = Mint)
                Spacer(Modifier.width(12.dp))
                Text("Notifications", color = White, modifier = Modifier.weight(1f))
                Switch(checked = notifications, onCheckedChange = { notifications = it })
            }
        }
        item { SettingRow(Icons.Default.Download, "Storage and downloads", "Manage offline audio", onDownloads) }
        item { SettingRow(Icons.Default.AdminPanelSettings, "Admin panel", "Authorized management preview", onAdmin) }
        item {
            Spacer(Modifier.height(8.dp))
            Text("About Quranify", color = Gold, fontWeight = FontWeight.Bold)
            Text("Listen • Learn • Connect\nVersion 1.0 • Quran metadata included locally", color = Muted, fontSize = 12.sp)
            Text("Admin preview is not secure authentication. Connect Firebase Auth and protected backend rules before production.", color = Gold, fontSize = 12.sp)
        }
    }
}

@Composable
private fun SettingRow(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, detail: String, onClick: (() -> Unit)? = null) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(SurfaceGreen)
            .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = Mint)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = White, fontWeight = FontWeight.SemiBold)
            Text(detail, color = Muted, fontSize = 11.sp)
        }
        if (onClick != null) Icon(Icons.Default.ChevronRight, null, tint = Muted)
    }
}

@Composable
private fun PlayerDialog(
    surah: Surah, reciter: Reciter, playing: Boolean, onToggle: () -> Unit, onClose: () -> Unit,
    onNext: () -> Unit, onPrevious: () -> Unit, onDownload: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onClose,
        containerColor = SurfaceGreen,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Now Playing", color = White, modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold)
                IconButton(onClick = onClose) { Icon(Icons.Default.Close, null, tint = Muted) }
            }
        },
        text = {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.fillMaxWidth().height(180.dp).clip(RoundedCornerShape(24.dp))
                    .background(Brush.linearGradient(listOf(Color(0xFF14563B), Color(0xFF071B14)))),
                    contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.MenuBook, null, tint = Gold, modifier = Modifier.size(74.dp))
                        Text("القرآن الكريم", color = Mint, fontSize = 23.sp)
                    }
                }
                Spacer(Modifier.height(16.dp))
                Text(surah.arabic, color = Gold, fontSize = 24.sp)
                Text(surah.english, color = White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text(reciter.name, color = Muted, fontSize = 12.sp)
                Text("${surah.verses} verses • Internet streaming", color = Muted, fontSize = 11.sp)
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onPrevious) { Icon(Icons.Default.SkipPrevious, null, tint = White, modifier = Modifier.size(32.dp)) }
                    FilledIconButton(onClick = onToggle, colors = IconButtonDefaults.filledIconButtonColors(containerColor = Mint, contentColor = Background), modifier = Modifier.size(58.dp)) {
                        Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, modifier = Modifier.size(32.dp))
                    }
                    IconButton(onClick = onNext) { Icon(Icons.Default.SkipNext, null, tint = White, modifier = Modifier.size(32.dp)) }
                }
                OutlinedButton(onClick = onDownload, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.Download, null); Spacer(Modifier.width(8.dp)); Text("Download current verse audio")
                }
                Text("Audio is streamed from EveryAyah. Availability depends on the selected reciter's server folder.", color = Muted, fontSize = 10.sp)
            }
        },
        confirmButton = { TextButton(onClick = onClose) { Text("Done", color = Mint) } }
    )
}
