package com.quranify.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Night = Color(0xFF101510)
private val Panel = Color(0xFF1C251D)
private val Green = Color(0xFF75C98B)
private val Gold = Color(0xFFE4C77A)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { QuranifyApp() }
    }
}

data class Reciter(val name: String, val subtitle: String)

@Composable
fun QuranifyApp() {
    var query by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf("Home") }
    var playing by remember { mutableStateOf(false) }
    val reciters = listOf(
        Reciter("محمد صديق المنشاوي", "Sheikh Muhammad Siddiq Al-Minshawi"),
        Reciter("عبد الباسط عبد الصمد", "Sheikh Abdul Basit Abdus Samad"),
        Reciter("محمود خليل الحصري", "Sheikh Mahmoud Khalil Al-Husary"),
        Reciter("محمود الشحات أنور", "Sheikh Mahmoud Shahat Anwar")
    )

    MaterialTheme(colorScheme = darkColorScheme(
        background = Night, surface = Panel, primary = Green, secondary = Gold
    )) {
        Scaffold(
            containerColor = Night,
            bottomBar = {
                NavigationBar(containerColor = Panel) {
                    listOf("Home", "Reciters", "Library", "Settings").forEach { item ->
                        NavigationBarItem(
                            selected = selected == item,
                            onClick = { selected = item },
                            icon = {
                                Icon(
                                    when (item) {
                                        "Home" -> Icons.Default.Home
                                        "Reciters" -> Icons.Default.Mic
                                        "Library" -> Icons.Default.LibraryMusic
                                        else -> Icons.Default.Settings
                                    }, contentDescription = item
                                )
                            },
                            label = { Text(item) }
                        )
                    }
                }
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Spacer(Modifier.height(12.dp))
                    Text("Quranify", color = Green, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                    Text("Listen. Reflect. Remember.", color = Gold, fontSize = 14.sp)
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(
                        value = query, onValueChange = { query = it },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("Search reciters or Surahs") },
                        leadingIcon = { Icon(Icons.Default.Search, null) },
                        singleLine = true,
                        shape = RoundedCornerShape(16.dp)
                    )
                }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Panel),
                        shape = RoundedCornerShape(20.dp)) {
                        Column(Modifier.padding(18.dp)) {
                            Text("Continue your spiritual journey", color = Gold, fontSize = 13.sp)
                            Spacer(Modifier.height(8.dp))
                            Text("سورة الفاتحة", color = Color.White, fontSize = 25.sp,
                                fontWeight = FontWeight.Bold)
                            Text("Al-Fatiha • 7 verses", color = Color.LightGray)
                            Spacer(Modifier.height(12.dp))
                            Button(onClick = { playing = !playing }) {
                                Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null)
                                Spacer(Modifier.width(8.dp))
                                Text(if (playing) "Pause" else "Play sample UI")
                            }
                            Text("Connect an authorized audio URL to enable real playback.",
                                color = Color.LightGray, fontSize = 12.sp)
                        }
                    }
                }
                item { Text("Popular Reciters", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold) }
                items(reciters.filter { it.subtitle.contains(query, true) || it.name.contains(query) }) { reciter ->
                    Card(colors = CardDefaults.cardColors(containerColor = Panel),
                        shape = RoundedCornerShape(16.dp)) {
                        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(48.dp).background(Green.copy(alpha = .18f), RoundedCornerShape(14.dp)),
                                contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.MusicNote, null, tint = Green)
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(reciter.name, color = Color.White, fontSize = 18.sp)
                                Text(reciter.subtitle, color = Color.LightGray, fontSize = 12.sp)
                            }
                            IconButton(onClick = { }) { Icon(Icons.Default.FavoriteBorder, null, tint = Gold) }
                        }
                    }
                }
                item {
                    Text("Admin & Firebase setup", color = Gold, fontWeight = FontWeight.Bold)
                    Text("This starter includes Firebase libraries, but you must connect your own Firebase project and secure admin authentication before cloud management works.",
                        color = Color.LightGray, fontSize = 13.sp)
                    Spacer(Modifier.height(20.dp))
                }
            }
        }
    }
}
