QURANIFY ANDROID PROJECT — FIXED

This archive includes the missing Android resource files and a usable Gradle launcher.
It is a compile-ready starter project for Android Studio/Gradle, provided the build
environment has Android SDK 35 and internet access for Gradle/Maven dependencies.

Included:
- Kotlin + Jetpack Compose UI
- Android resources: strings.xml, colors.xml, themes.xml
- AndroidManifest using the app theme
- Reciters including Sheikh Mahmoud Shahat Anwar
- Media3 dependencies
- Firebase Auth/Firestore dependencies (Firebase config is NOT included)
- Linux/macOS gradlew launcher
- Windows gradlew.bat launcher

Build:
1. Open the extracted folder in Android Studio.
2. Let Gradle sync and install missing SDK components if Android Studio asks.
3. Build > Make Project.
4. Debug APK: app/build/outputs/apk/debug/app-debug.apk

Firebase:
Firebase is intentionally not configured in this archive. If cloud admin features
are added, put your own google-services.json in app/ and enable the Google Services
plugin in app/build.gradle.kts. Never hard-code an admin password in the APK.

Note:
A standard gradle-wrapper.jar is not required by the included launchers; they download
Gradle 8.9 directly. Android Studio can also use its configured Gradle tooling.
