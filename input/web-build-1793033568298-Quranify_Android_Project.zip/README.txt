QURANIFY ANDROID STARTER PROJECT

What is included:
- Kotlin + Jetpack Compose starter UI
- Android Gradle build files
- Gradle 8.9 distribution properties
- A lightweight ./gradlew launcher that downloads Gradle on first use
- Firebase Auth / Firestore dependencies prepared
- Media3 dependencies prepared

IMPORTANT:
This is a starter project, not a finished production Quran streaming app.
The sample Play button changes UI state only; real audio playback and a secure
admin CRUD screen still need implementation. Firebase libraries are included,
but Firebase is not connected until you add your own app configuration.

Firebase setup:
1. Open https://console.firebase.google.com/
2. Create a project named Quranify.
3. Add an Android app with package name: com.quranify.app
4. Download google-services.json and put it in the app/ folder.
5. In app/build.gradle.kts, uncomment:
   id("com.google.gms.google-services")
   inside plugins.
6. In root build.gradle.kts, the Google Services plugin is already declared.
7. Enable Authentication providers you intend to use and create a Firestore database.
8. Configure secure Firestore rules. Do not allow public writes or store admin passwords in the app.
9. Sync Gradle and build again.

Build command (Linux / Codespaces / supported shell):
  chmod +x gradlew
  ./gradlew assembleDebug

APK output:
  app/build/outputs/apk/debug/app-debug.apk

Requirements:
- JDK 17
- Internet access for downloading Gradle and dependencies
- curl or wget and unzip for the included lightweight launcher

If using Windows, open the project in Android Studio and let Android Studio sync
the Gradle project. The included gradlew.bat is only a notice stub; use Android
Studio's Gradle tooling or generate a standard Gradle wrapper there.

Do not publish Firebase configuration or security rules that grant unrestricted writes.
