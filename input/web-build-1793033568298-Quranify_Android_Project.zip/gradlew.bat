@echo off
echo This lightweight launcher requires a Unix-like shell with curl/wget and unzip.
echo On Windows, open this project in Android Studio and use its Gradle sync/build.
exit /b 1
